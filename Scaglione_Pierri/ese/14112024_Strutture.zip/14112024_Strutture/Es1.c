/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    struct inventory {
    char partName[30];  // Nome della parte
    int partNumber;     // Numero della parte
    float price;        // Prezzo
    int stock;          // Quantità in magazzino
    int reorder;        // Soglia di riordino
};

struct data {
    char c;      // Carattere
    short s;     // Intero corto
    long b;      // Intero lungo
    float f;     // Numero in virgola mobile
    double d;    // Numero in virgola mobile doppia precisione
};

struct address {
    char streetAddress[25]; // Indirizzo stradale
    char city[20];          // Città
    char state[3];          // Stato (abbreviazione di 2 lettere + terminatore)
    char zipCode[6];        // Codice postale (5 caratteri + terminatore)
};

struct student {
    char firstName[15];         // Nome
    char lastName[15];          // Cognome
    struct address homeAddress; // Indirizzo di casa, di tipo struct address
};

struct test {
    unsigned int a: 1;
    unsigned int b: 1;
    unsigned int c: 1;
    unsigned int d: 1;
    unsigned int e: 1;
    unsigned int f: 1;
    unsigned int g: 1;
    unsigned int h: 1;
    unsigned int i: 1;
    unsigned int j: 1;
    unsigned int k: 1;
    unsigned int l: 1;
    unsigned int m: 1;
    unsigned int n: 1;
    unsigned int o: 1;
    unsigned int p: 1;
};


    return 0;
}