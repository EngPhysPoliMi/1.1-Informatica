#include <stdio.h>

struct Product {
    char name[30];
    int partNumber;
    float price;
    int stock;
};

// Funzione per acquisire i dati di un prodotto
void inputProduct(struct Product *p) {
    printf("Inserisci il nome del prodotto: ");
    scanf("%s", p->name);
    printf("Inserisci il numero del prodotto: ");
    scanf("%d", &p->partNumber);
    printf("Inserisci il prezzo: ");
    scanf("%f", &p->price);
    printf("Inserisci la quantità in magazzino: ");
    scanf("%d", &p->stock);
}

// Funzione per visualizzare i dati di un prodotto
void displayProduct(struct Product p) {
    printf("\nNome: %s\nNumero: %d\nPrezzo: %.2f\nStock: %d\n", p.name, p.partNumber, p.price, p.stock);
}

int main() {
    struct Product inventory[5];
    for (int i = 0; i < 2; i++) {
        printf("\n--- Prodotto %d ---\n", i + 1);
        inputProduct(&inventory[i]);
    }
    printf("\n--- Inventario ---\n");
    for (int i = 0; i < 2; i++) {
        displayProduct(inventory[i]);
    }
    return 0;
}
