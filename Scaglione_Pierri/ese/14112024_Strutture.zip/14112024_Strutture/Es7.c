#include <stdio.h>

int main() {
    int num, shift;

    // Acquisizione del numero e del numero di bit da spostare
    printf("Inserisci un numero intero: ");
    scanf("%d", &num);
    printf("Inserisci il numero di bit da spostare: ");
    scanf("%d", &shift);

    // Calcolo del risultato dello shift a sinistra e a destra
    int leftShift = num << shift;   // Moltiplica per 2^shift
    int rightShift = num >> shift;  // Divide per 2^shift

    // Visualizzazione dei risultati
    printf("\n%d << %d = %d  (moltiplicato per %d)\n", num, shift, leftShift, 1 << shift);
    printf("%d >> %d = %d  (diviso per %d)\n", num, shift, rightShift, 1 << shift);

    return 0;
}