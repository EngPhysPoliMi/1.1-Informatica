#include <stdio.h>

struct Exam {
    char subject[30];
    int grade;
    int credits;
};

int main() {
    struct Exam exams[3];

    // Acquisizione dei dati per 3 esami
    for (int i = 0; i < 3; i++) {
        printf("\n--- Inserisci i dati per l'esame %d ---\n", i + 1);
        printf("Nome della materia: ");
        scanf("%s", exams[i].subject);
        printf("Voto ottenuto: ");
        scanf("%d", &exams[i].grade);
        printf("CFU associati: ");
        scanf("%d", &exams[i].credits);
    }

    // Visualizzazione dei dati acquisiti
    printf("\n--- Registro Esami ---\n");
    for (int i = 0; i < 3; i++) {
        printf("\nMateria: %s\n", exams[i].subject);
        printf("Voto: %d\n", exams[i].grade);
        printf("CFU: %d\n", exams[i].credits);
    }

    return 0;
}
