#include <stdio.h>

struct Animal {
    char name[20];
    char species[20];
    int age;
};

int main() {
    struct Animal myAnimal;

    // Acquisizione dei dati dell'animale
    printf("Inserisci il nome dell'animale: ");
    scanf("%s", myAnimal.name);
    printf("Inserisci la specie dell'animale: ");
    scanf("%s", myAnimal.species);
    printf("Inserisci l'età dell'animale: ");
    scanf("%d", &myAnimal.age);

    // Visualizzazione dei dati acquisiti
    printf("\n--- Dettagli Animale ---\n");
    printf("Nome: %s\n", myAnimal.name);
    printf("Specie: %s\n", myAnimal.species);
    printf("Età: %d anni\n", myAnimal.age);

    return 0;
}
