#include <stdio.h>

struct Student {
    char firstName[20];
    char lastName[20];
    float grades[3];
};

// Funzione per acquisire i dati di uno studente
void inputStudent(struct Student *s) {
    printf("Inserisci il nome dello studente: ");
    scanf("%s", s->firstName);
    printf("Inserisci il cognome dello studente: ");
    scanf("%s", s->lastName);
    for (int i = 0; i < 3; i++) {
        printf("Inserisci il voto %d: ", i + 1);
        scanf("%f", &s->grades[i]);
    }
}

// Funzione per calcolare la media dei voti
float calculateAverage(float grades[], int size) {
    float sum = 0.0;
    for (int i = 0; i < size; i++) {
        sum += grades[i];
    }
    return sum / size;
}

// Funzione per visualizzare i dati dello studente
void displayStudent(struct Student s) {
    printf("\nNome: %s %s\n", s.firstName, s.lastName);
    float average = calculateAverage(s.grades, 3);
    printf("Media voti: %.2f\n", average);
}

int main() {
    struct Student student;
    inputStudent(&student);
    displayStudent(student);
    return 0;
}
