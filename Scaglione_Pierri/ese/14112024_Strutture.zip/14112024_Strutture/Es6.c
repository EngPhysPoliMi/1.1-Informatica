#include <stdio.h>
#include <string.h>

struct Contact {
    char name[30];
    char phone[15];
};

// Funzione per aggiungere un contatto
void addContact(struct Contact contacts[], int *count) {
    printf("Inserisci il nome del contatto: ");
    scanf("%s", contacts[*count].name);
    printf("Inserisci il numero di telefono: ");
    scanf("%s", contacts[*count].phone);
    (*count)++;
}

// Funzione per cercare un contatto per nome
void searchContact(struct Contact contacts[], int count) {
    char searchName[30];
    printf("Inserisci il nome da cercare: ");
    scanf("%s", searchName);
    for (int i = 0; i < count; i++) {
        if (strcmp(contacts[i].name, searchName) == 0) {
            printf("Contatto trovato: %s - %s\n", contacts[i].name, contacts[i].phone);
            return;
        }
    }
    printf("Contatto non trovato.\n");
}

// Funzione per visualizzare tutti i contatti
void displayContacts(struct Contact contacts[], int count) {
    printf("\n--- Rubrica ---\n");
    for (int i = 0; i < count; i++) {
        printf("%s - %s\n", contacts[i].name, contacts[i].phone);
    }
}

int main() {
    struct Contact contacts[50];
    int count = 0;
    int choice;

    do {
        printf("\n1. Aggiungi contatto\n2. Cerca contatto\n3. Visualizza tutti i contatti\n4. Esci\n");
        printf("Scegli un'opzione: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addContact(contacts, &count);
                break;
            case 2:
                searchContact(contacts, count);
                break;
            case 3:
                displayContacts(contacts, count);
                break;
            case 4:
                printf("Uscita...\n");
                break;
            default:
                printf("Opzione non valida.\n");
        }
    } while (choice != 4);

    return 0;
}
