#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Struttura per rappresentare un nodo della coda
typedef struct Node {
    char name[30];       // Nome del cliente
    int operationNumber; // Numero di operazione
    struct Node* next;   // Puntatore al nodo successivo
} Node;

// Puntatori per la testa e la coda della coda
Node* front = NULL;
Node* rear = NULL;

// Funzione per aggiungere un cliente alla coda
void enqueue(char name[], int operationNumber) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    strcpy(newNode->name, name);
    newNode->operationNumber = operationNumber;
    newNode->next = NULL;

    if (rear == NULL) { // Se la coda è vuota
        front = rear = newNode;
    } else {
        rear->next = newNode;
        rear = newNode;
    }

    printf("Cliente %s (Operazione %d) aggiunto alla fila.\n", name, operationNumber);
}

// Funzione per servire il prossimo cliente
void dequeue() {
    if (front == NULL) {
        printf("Nessun cliente in fila.\n");
        return;
    }

    Node* temp = front;
    printf("Servendo cliente %s (Operazione %d).\n", temp->name, temp->operationNumber);
    front = front->next;

    if (front == NULL) { // Se la coda diventa vuota
        rear = NULL;
    }

    free(temp);
}

// Funzione per visualizzare lo stato attuale della coda
void printQueue() {
    if (front == NULL) {
        printf("Nessun cliente in fila.\n");
        return;
    }

    printf("Stato attuale della fila:\n");
    Node* current = front;
    while (current != NULL) {
        printf("%s (Operazione %d) -> ", current->name, current->operationNumber);
        current = current->next;
    }
    printf("NULL\n");
}

// Funzione principale
int main() {
    int scelta, operationNumber;
    char name[30];

    do {
        printf("\nMenu:\n");
        printf("1. Aggiungi un cliente alla fila\n");
        printf("2. Servi il prossimo cliente\n");
        printf("3. Visualizza la fila\n");
        printf("4. Esci\n");
        printf("Scelta: ");
        scanf("%d", &scelta);

        switch (scelta) {
            case 1:
                printf("Inserisci il nome del cliente: ");
                scanf("%s", name);
                printf("Inserisci il numero dell'operazione: ");
                scanf("%d", &operationNumber);
                enqueue(name, operationNumber);
                break;
            case 2:
                dequeue();
                break;
            case 3:
                printQueue();
                break;
            case 4:
                printf("Uscita...\n");
                break;
            default:
                printf("Scelta non valida, riprova.\n");
        }
    } while (scelta != 4);

    return 0;
}
