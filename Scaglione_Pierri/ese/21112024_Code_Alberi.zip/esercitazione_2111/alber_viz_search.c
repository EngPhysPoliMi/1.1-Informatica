/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

typedef struct Node{
    int data;
    struct Node* left; // figlio sinistro
    struct Node* right; // figlio destro
}Node;



Node* insert(Node* root, int data);
void printTree(Node* root, int space);
Node* createNode(int data);
void printOrder(Node* root);
int search(Node* root, int value);

Node* createNode(int data){
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

void printOrder(Node* root){
    if(root != NULL){
        printOrder(root->left);
        printf("%d",root->data);
        printOrder(root->right);
    }
    return;
}


Node* insert(Node* root, int data){
    if(root == NULL){
        return createNode(data);
    }
    
    if( data < root->data){
        root->left = insert(root->left,data);
    }else{
        root-> right = insert(root->right,data);
    }
    return root;
}

int search(Node* root, int value){
    if(root->data == value){
        return value;
    }
    
    if( value < root->data && root->left != NULL){
        return search(root->left,value);
    }else if(value >= root->data && root->right != NULL){
        return search(root->right,value);
    }
    return -1;
}

void printTree(Node* root, int space){
    if(root == NULL){
        return;
    }
    space += 10;
    printTree(root->right, space);
    printf("\n");
    for(int i=0;i< space;i++){
        printf(" ");
    }
    printf("%d\n", root->data);
    
    printTree(root->left, space);
}


int main()
{
    Node* root = NULL;
    int num, n;
    
    printf("Quanti numeri vuoi inserire nell' albero? ");
    scanf("%d",&n);
    
    for(int i = 0; i < n; i++){
        printf("Inserisci il numero: ");
        scanf("%d",&num);
        root = insert(root,num);
    }
    
    //printf("Albero binario: \n");
    //printTree(root,0);
    //printOrder(root);
    printf("Inserisci il numero da cercare: ");
    scanf("%d",&num);
    printf("%d",search(root,num));

    return 0;
}
