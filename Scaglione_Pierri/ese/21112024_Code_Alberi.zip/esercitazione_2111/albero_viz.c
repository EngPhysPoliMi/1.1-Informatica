#include <stdio.h>
#include <stdlib.h>

// Struttura del nodo dell'albero binario
typedef struct Node {
    int data;               // Valore del nodo
    struct Node* left;      // Puntatore al nodo sinistro
    struct Node* right;     // Puntatore al nodo destro
} Node;

// Funzione per creare un nuovo nodo con un valore specificato
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->left = newNode->right = NULL;
    return newNode;
}

// Funzione per inserire un valore nell'albero binario
Node* insert(Node* root, int data) {
    if (root == NULL) {
        return createNode(data);
    }
    
    if (data < root->data) {
        root->left = insert(root->left, data);  // Inserisce a sinistra
    } else {
        root->right = insert(root->right, data); // Inserisce a destra
    }
    return root;
}

// Funzione per stampare l'albero in ordine
void inorder(Node* root) {
    if (root != NULL) {
        inorder(root->left);   // Visita il sottoalbero sinistro
        printf("%d ", root->data);  // Stampa il nodo corrente
        inorder(root->right);  // Visita il sottoalbero destro
    }
}

// Funzione per stampare l'albero in una forma grafica
void printTree(Node* root, int space) {
    if (root == NULL)
        return;

    // Incrementa lo spazio per il livello successivo
    space += 10;

    // Stampa il sottoalbero destro prima (come se fosse più in alto)
    printTree(root->right, space);

    // Stampa il nodo corrente
    printf("\n");
    for (int i = 10; i < space; i++) {
        printf(" ");  // Indenta per creare la forma dell'albero
    }
    printf("%d\n", root->data);

    // Stampa il sottoalbero sinistro
    printTree(root->left, space);
}

// Funzione principale
int main() {
    Node* root = NULL;
    int num, n;

    // Chiedi all'utente quanti numeri vuole inserire
    printf("Quanti numeri vuoi inserire nell'albero? ");
    scanf("%d", &n);

    // Chiedi all'utente di inserire i numeri
    for (int i = 0; i < n; i++) {
        printf("Inserisci un numero: ");
        scanf("%d", &num);
        root = insert(root, num);
    }

    // Stampa l'albero in forma grafica
    printf("Albero binario:\n");
    printTree(root, 0);

    return 0;
}
