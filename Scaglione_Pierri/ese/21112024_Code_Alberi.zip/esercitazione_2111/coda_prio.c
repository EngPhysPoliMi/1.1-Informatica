#include <stdio.h>
#include <stdlib.h>

// Struttura per rappresentare un nodo della coda
typedef struct Node {
    int value;         // Valore dell'elemento
    int priority;      // Priorità dell'elemento
    struct Node* next; // Puntatore al nodo successivo
} Node;

// Puntatore alla testa della coda
Node* front = NULL;

// Funzione per creare un nuovo nodo
Node* createNode(int value, int priority) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->value = value;
    newNode->priority = priority;
    newNode->next = NULL;
    return newNode;
}

// Funzione per inserire un elemento nella coda con priorità
void enqueue(int value, int priority) {
    Node* newNode = createNode(value, priority);

    // Se la coda è vuota o il nuovo elemento ha la priorità più alta
    if (front == NULL || priority > front->priority) {
        newNode->next = front;
        front = newNode;
    } else {
        // Inserisci il nuovo nodo nella posizione corretta
        Node* current = front;
        while (current->next != NULL && current->next->priority >= priority) {
            current = current->next;
        }
        newNode->next = current->next;
        current->next = newNode;
    }
}

// Funzione per rimuovere l'elemento con la priorità più alta
void dequeue() {
    if (front == NULL) {
        printf("Coda vuota, nessun elemento da rimuovere.\n");
        return;
    }
    Node* temp = front;
    printf("Elemento rimosso: valore = %d, priorità = %d\n", temp->value, temp->priority);
    front = front->next;
    free(temp);
}

// Funzione per stampare gli elementi della coda
void printQueue() {
    if (front == NULL) {
        printf("Coda vuota.\n");
        return;
    }
    printf("Stato attuale della coda (valore, priorità):\n");
    Node* current = front;
    while (current != NULL) {
        printf("(%d, %d) ", current->value, current->priority);
        current = current->next;
    }
    printf("\n");
}

// Funzione principale
int main() {
    int scelta, valore, priorita;

    do {
        printf("\nMenu:\n");
        printf("1. Inserisci un elemento nella coda\n");
        printf("2. Rimuovi l'elemento con priorità più alta\n");
        printf("3. Visualizza la coda\n");
        printf("4. Esci\n");
        printf("Scelta: ");
        scanf("%d", &scelta);

        switch (scelta) {
            case 1:
                printf("Inserisci il valore: ");
                scanf("%d", &valore);
                printf("Inserisci la priorità: ");
                scanf("%d", &priorita);
                enqueue(valore, priorita);
                break;
            case 2:
                dequeue();
                break;
            case 3:
                printQueue();
                break;
            case 4:
                printf("Uscita...\n");
                break;
            default:
                printf("Scelta non valida, riprova.\n");
        }
    } while (scelta != 4);

    return 0;
}
