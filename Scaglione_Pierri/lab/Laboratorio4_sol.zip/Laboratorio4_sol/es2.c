#include <stdio.h>
#include <stdlib.h>

// Definizione delle strutture
typedef int Data;

struct listNode {
    Data data;                 // Ogni nodo contiene un valore di tipo Data
    struct listNode *nextPtr;  // Puntatore al nodo successivo
};

typedef struct listNode ListNode;      // Sinonimo per struct listNode
typedef ListNode *ListNodePtr;         // Puntatore a un nodo della lista

// Funzione per creare un nuovo nodo
ListNodePtr createNode(Data data) {
    ListNodePtr newNode = malloc(sizeof(ListNode));
    if (newNode != NULL) {
        newNode->data = data;
        newNode->nextPtr = NULL;
    }
    return newNode;
}

// Funzione per aggiungere un nodo alla fine della lista
void appendNode(ListNodePtr *head, Data data) {
    ListNodePtr newNode = createNode(data);
    if (newNode == NULL) {
        printf("Errore: impossibile allocare memoria per un nuovo nodo.\n");
        return;
    }

    if (*head == NULL) {
        *head = newNode;  // La lista era vuota, il nuovo nodo diventa la testa
    } else {
        ListNodePtr current = *head;
        while (current->nextPtr != NULL) {
            current = current->nextPtr;
        }
        current->nextPtr = newNode;
    }
}

// Funzione iterativa per calcolare la somma degli elementi
int somma_iterativa(ListNodePtr head) {
    int total = 0; // Inizializza la somma a zero
    while (head != NULL) {
        total += head->data;  // Aggiungi il valore del nodo corrente
        head = head->nextPtr; // Passa al nodo successivo
    }
    return total; // Restituisci la somma
}

// Funzione ricorsiva per calcolare la somma degli elementi
int somma_ricorsiva(ListNodePtr head) {
    if (head == NULL) {
        return 0; // Caso base: se la lista è vuota, restituisci 0
    }
    return head->data + somma_ricorsiva(head->nextPtr); // Somma il valore corrente al resto della lista
}

// Funzione per stampare la lista
void printList(ListNodePtr head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->nextPtr;
    }
    printf("NULL\n");
}

// Funzione principale per testare
int main() {
    ListNodePtr head = NULL;  // Inizializza la lista vuota

    // Aggiungi elementi alla lista
    appendNode(&head, 10);
    appendNode(&head, 20);
    appendNode(&head, 30);
    appendNode(&head, 40);

    printf("Lista: ");
    printList(head);

    // Calcola la somma iterativamente
    int sum_iter = somma_iterativa(head);
    printf("Somma (iterativa): %d\n", sum_iter);

    // Calcola la somma ricorsivamente
    int sum_rec = somma_ricorsiva(head);
    printf("Somma (ricorsiva): %d\n", sum_rec);

    // Liberare la memoria
    while (head != NULL) {
        ListNodePtr temp = head;
        head = head->nextPtr;
        free(temp);
    }

    return 0;
}
