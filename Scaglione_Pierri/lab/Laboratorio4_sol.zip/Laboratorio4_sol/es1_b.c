#include <stdio.h>
#include <stdlib.h>

// Definizione delle strutture
typedef int Data;

struct listNode {
    Data data;                 // Ogni nodo contiene un valore di tipo Data
    struct listNode *nextPtr;  // Puntatore al nodo successivo
};

typedef struct listNode ListNode;      // Sinonimo per struct listNode
typedef ListNode *ListNodePtr;         // Puntatore a un nodo della lista

// Funzione per creare un nuovo nodo
ListNodePtr createNode(Data data) {
    ListNodePtr newNode = malloc(sizeof(ListNode));
    if (newNode != NULL) {
        newNode->data = data;
        newNode->nextPtr = NULL;
    }
    return newNode;
}

// Funzione ricorsiva per costruire la lista a partire dall'array
ListNodePtr buildFromArray_recursive(int arr[], int n_elems) {
    if (n_elems == 0) {
        return NULL;  // Caso base: l'array è vuoto, restituisce NULL
    }

    // Crea il nodo per il primo elemento
    ListNodePtr head = createNode(arr[0]);
    if (head == NULL) {
        printf("Errore: memoria insufficiente per il nodo.\n");
        return NULL;
    }

    // Collega ricorsivamente il resto della lista
    head->nextPtr = buildFromArray_recursive(arr + 1, n_elems - 1);
    return head;
}

// Funzione per stampare la lista
void printList(ListNodePtr head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->nextPtr;
    }
    printf("NULL\n");
}

// Funzione principale per testare il codice
int main() {
    int array[] = {10, 20, 30, 40, 50};  // Array di numeri
    int n_elems = sizeof(array) / sizeof(array[0]);  // Calcolo del numero di elementi

    // Costruisci la lista a partire dall'array
    ListNodePtr head = buildFromArray_recursive(array, n_elems);

    // Stampa la lista risultante
    printf("Lista costruita dall'array: ");
    printList(head);

    // Liberare la memoria (facoltativo ma buona pratica)
    while (head != NULL) {
        ListNodePtr temp = head;
        head = head->nextPtr;
        free(temp);
    }

    return 0;
}
