#include <stdio.h>
#include <stdlib.h>

// Definizione delle strutture
typedef int Data;

struct listNode {
    Data data;                 // Ogni nodo contiene un valore di tipo Data
    struct listNode *nextPtr;  // Puntatore al nodo successivo
};

typedef struct listNode ListNode;      // Sinonimo per struct listNode
typedef ListNode *ListNodePtr;         // Puntatore a un nodo della lista

// Funzione per creare un nuovo nodo
ListNodePtr createNode(Data data) {
    ListNodePtr newNode = malloc(sizeof(ListNode));
    if (newNode != NULL) {
        newNode->data = data;
        newNode->nextPtr = NULL;
    }
    return newNode;
}

// Funzione per aggiungere un nodo alla fine della lista
void appendNode(ListNodePtr *head, Data data) {
    ListNodePtr newNode = createNode(data);
    if (newNode == NULL) {
        printf("Errore: impossibile allocare memoria per un nuovo nodo.\n");
        return;
    }

    if (*head == NULL) {
        *head = newNode;  // La lista era vuota, il nuovo nodo diventa la testa
    } else {
        ListNodePtr current = *head;
        while (current->nextPtr != NULL) {
            current = current->nextPtr;
        }
        current->nextPtr = newNode;
    }
}

// Funzione per creare una nuova lista con soli valori pari
ListNodePtr onlyEven(ListNodePtr head) {
    ListNodePtr newHead = NULL;  // Nuova lista vuota

    while (head != NULL) {
        if (head->data % 2 == 0) {  // Controlla se il valore è pari
            appendNode(&newHead, head->data); // Usa appendNode per aggiungere il valore
        }
        head = head->nextPtr; // Passa al prossimo nodo
    }

    return newHead; // Restituisci la testa della nuova lista
}


// Funzione per stampare la lista
void printList(ListNodePtr head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->nextPtr;
    }
    printf("NULL\n");
}

// Funzione principale per testare
int main() {
    ListNodePtr head = NULL;  // Inizializza la lista vuota

    // Aggiungi elementi alla lista
    appendNode(&head, 10);
    appendNode(&head, 15);
    appendNode(&head, 20);
    appendNode(&head, 25);
    appendNode(&head, 30);

    printf("Lista originale: ");
    printList(head);

    // Crea la lista con soli valori pari
    ListNodePtr evenList = onlyEven(head);
    printf("Lista con soli valori pari: ");
    printList(evenList);

    // Liberare la memoria per entrambe le liste
    while (head != NULL) {
        ListNodePtr temp = head;
        head = head->nextPtr;
        free(temp);
    }

    while (evenList != NULL) {
        ListNodePtr temp = evenList;
        evenList = evenList->nextPtr;
        free(temp);
    }

    return 0;
}
