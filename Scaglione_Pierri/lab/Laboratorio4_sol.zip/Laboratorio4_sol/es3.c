#include <stdio.h>
#include <stdlib.h>

// Definizione delle strutture
typedef int Data;

struct listNode {
    Data data;                 // Ogni nodo contiene un valore di tipo Data
    struct listNode *nextPtr;  // Puntatore al nodo successivo
};

typedef struct listNode ListNode;      // Sinonimo per struct listNode
typedef ListNode *ListNodePtr;         // Puntatore a un nodo della lista

// Funzione per creare un nuovo nodo
ListNodePtr createNode(Data data) {
    ListNodePtr newNode = malloc(sizeof(ListNode));
    if (newNode != NULL) {
        newNode->data = data;
        newNode->nextPtr = NULL;
    }
    return newNode;
}

// Funzione per aggiungere un nodo alla fine della lista
void appendNode(ListNodePtr *head, Data data) {
    ListNodePtr newNode = createNode(data);
    if (newNode == NULL) {
        printf("Errore: impossibile allocare memoria per un nuovo nodo.\n");
        return;
    }

    if (*head == NULL) {
        *head = newNode;  // La lista era vuota, il nuovo nodo diventa la testa
    } else {
        ListNodePtr current = *head;
        while (current->nextPtr != NULL) {
            current = current->nextPtr;
        }
        current->nextPtr = newNode;
    }
}

// Funzione iterativa per trovare il massimo
int massimo_iterativo(ListNodePtr head) {
    if (head == NULL) {
        printf("Errore: lista vuota.\n");
        return -1; // Valore arbitrario per indicare errore
    }

    int max = head->data; // Inizializza il massimo con il primo elemento
    while (head != NULL) {
        if (head->data > max) {
            max = head->data; // Aggiorna il massimo se necessario
        }
        head = head->nextPtr; // Passa al nodo successivo
    }
    return max; // Restituisci il massimo
}

// Funzione ricorsiva per trovare il massimo
int massimo_ricorsivo(ListNodePtr head) {
    if (head == NULL) {
        printf("Errore: lista vuota.\n");
        return -1; // Valore arbitrario per indicare errore
    }

    if (head->nextPtr == NULL) {
        return head->data; // Caso base: se è l'ultimo nodo, restituisci il suo valore
    }

    int max_rest = massimo_ricorsivo(head->nextPtr); // Massimo del resto della lista
    return (head->data > max_rest) ? head->data : max_rest; // Confronta e restituisci il massimo
}

// Funzione per stampare la lista
void printList(ListNodePtr head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->nextPtr;
    }
    printf("NULL\n");
}

// Funzione principale per testare
int main() {
    ListNodePtr head = NULL;  // Inizializza la lista vuota

    // Aggiungi elementi alla lista
    appendNode(&head, 10);
    appendNode(&head, 50);
    appendNode(&head, 30);
    appendNode(&head, 20);

    printf("Lista: ");
    printList(head);

    // Trova il massimo iterativamente
    int max_iter = massimo_iterativo(head);
    printf("Massimo (iterativo): %d\n", max_iter);

    // Trova il massimo ricorsivamente
    int max_rec = massimo_ricorsivo(head);
    printf("Massimo (ricorsivo): %d\n", max_rec);

    // Liberare la memoria
    while (head != NULL) {
        ListNodePtr temp = head;
        head = head->nextPtr;
        free(temp);
    }

    return 0;
}
