#include <stdio.h>
#include <stdlib.h>

// Definizione delle strutture
typedef int Data;

struct listNode {
    Data data;                 // Ogni nodo contiene un valore di tipo Data
    struct listNode *nextPtr;  // Puntatore al nodo successivo
};

typedef struct listNode ListNode;      // Sinonimo per struct listNode
typedef ListNode *ListNodePtr;         // Puntatore a un nodo della lista

// Funzione per creare un nuovo nodo
ListNodePtr createNode(Data data) {
    ListNodePtr newNode = malloc(sizeof(ListNode));
    if (newNode != NULL) {
        newNode->data = data;
        newNode->nextPtr = NULL;
    }
    return newNode;
}

// Funzione per costruire una lista a partire da un array in modo iterativo
ListNodePtr buildFromArray_iterative(ListNodePtr head, int arr[], int n_elems) {
    if (n_elems == 0) {
        return NULL;  // Se non ci sono elementi, la lista è vuota
    }

    head = createNode(arr[0]);  // Crea il nodo per la testa
    if (head == NULL) {
        printf("Errore: memoria insufficiente per il nodo.\n");
        return NULL;
    }

    ListNodePtr current = head;  // Puntatore per costruire la lista

    // Itera sugli altri elementi dell'array
    for (int i = 1; i < n_elems; i++) {
        ListNodePtr newNode = createNode(arr[i]);
        if (newNode == NULL) {
            printf("Errore: memoria insufficiente per il nodo.\n");
            return NULL;
        }
        current->nextPtr = newNode;  // Collega il nuovo nodo
        current = newNode;          // Avanza il puntatore
    }

    return head;
}

// Funzione per stampare la lista
void printList(ListNodePtr head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->nextPtr;
    }
    printf("NULL\n");
}

// Funzione principale per testare il codice
int main() {
    int array[] = {10, 20, 30, 40, 50};  // Array di numeri
    int n_elems = sizeof(array) / sizeof(array[0]);  // Calcolo del numero di elementi

    ListNodePtr head = NULL;  // Inizializza la testa della lista

    // Costruisci la lista a partire dall'array
    head = buildFromArray_iterative(head, array, n_elems);

    // Stampa la lista risultante
    printf("Lista costruita dall'array: ");
    printList(head);

    // Liberare la memoria (facoltativo ma buona pratica)
    while (head != NULL) {
        ListNodePtr temp = head;
        head = head->nextPtr;
        free(temp);
    }

    return 0;
}
