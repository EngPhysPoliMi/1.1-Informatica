#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Definizione delle strutture
typedef int Data;

struct listNode {
    Data data;                 // Ogni nodo contiene un valore di tipo Data
    struct listNode *nextPtr;  // Puntatore al nodo successivo
};

typedef struct listNode ListNode;      // Sinonimo per struct listNode
typedef ListNode *ListNodePtr;         // Puntatore a un nodo della lista

// Funzione per verificare se una lista è vuota
bool isEmpty(ListNodePtr head) {
    return head == NULL;
}

// Funzione per ottenere l'ultimo nodo della lista
ListNodePtr last(ListNodePtr head) {
    if (isEmpty(head)) {
        return NULL;
    }
    while (head->nextPtr != NULL) {
        head = head->nextPtr;
    }
    return head;
}

// Funzione per ottenere la "coda" della lista (la lista senza il primo elemento)
ListNodePtr tail(ListNodePtr head) {
    if (isEmpty(head)) {
        return NULL;
    }
    return head->nextPtr;
}

// Funzione per creare un nuovo nodo
ListNodePtr createNode(Data data) {
    ListNodePtr newNode = malloc(sizeof(ListNode));
    if (newNode != NULL) {
        newNode->data = data;
        newNode->nextPtr = NULL;
    }
    return newNode;
}

// Funzione per aggiungere un nodo alla fine della lista
void appendNode(ListNodePtr *head, Data data) {
    ListNodePtr newNode = createNode(data);
    if (newNode == NULL) {
        printf("Errore: impossibile allocare memoria per un nuovo nodo.\n");
        return;
    }

    if (*head == NULL) {
        *head = newNode;  // La lista era vuota, il nuovo nodo diventa la testa
    } else {
        ListNodePtr lastNode = last(*head);
        lastNode->nextPtr = newNode;
    }
}

// Funzione per stampare la lista
void printList(ListNodePtr head) {
    while (head != NULL) {
        printf("%d -> ", head->data);
        head = head->nextPtr;
    }
    printf("NULL\n");
}

// Funzione principale per testare le funzioni
int main() {
    ListNodePtr head = NULL;  // Lista inizialmente vuota

    // Popolamento della lista
    appendNode(&head, 10);
    appendNode(&head, 20);
    appendNode(&head, 30);
    appendNode(&head, 40);

    printf("Lista iniziale: ");
    printList(head);

    printf("\nLa lista è vuota? %s\n", isEmpty(head) ? "Sì" : "No");

    ListNodePtr lastNode = last(head);
    if (lastNode != NULL) {
        printf("Ultimo nodo della lista: %d\n", lastNode->data);
    }

    ListNodePtr tailList = tail(head);
    printf("Coda della lista (senza la testa): ");
    printList(tailList);

    // Liberare la memoria (facoltativo ma buona pratica)
    while (head != NULL) {
        ListNodePtr temp = head;
        head = head->nextPtr;
        free(temp);
    }

    return 0;
}
