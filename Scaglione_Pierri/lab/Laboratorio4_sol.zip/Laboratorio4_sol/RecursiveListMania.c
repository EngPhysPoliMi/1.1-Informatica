//
//  main.c
//  RecursiveListMania
//
//  Created by ing.conti on 19/11/23.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#define  MAX_ELEMS 5

/* As per code seen at lesson from Deitel:


// self-referential structure
struct listNode {
   char data; // each listNode contains a character
   struct listNode *nextPtr; // pointer to next node
};

typedef struct listNode ListNode; // synonym for struct listNode
typedef ListNode *ListNodePtr; // synonym for ListNode*
*/

//eventually redefined in this way:



typedef int Data;
struct listNode {
    Data data; // each listNode contains a "Data"
   struct listNode *nextPtr; // pointer to next node
};


typedef struct listNode ListNode; // synonym for struct listNode
typedef ListNode *ListNodePtr; // synonym for ListNode*



// ancillary functions:

bool isEmpty(ListNodePtr head);
ListNodePtr buildFromArray(ListNodePtr head, int arr[], int n_elems);
void print(ListNodePtr head, bool reverse);
int somma(ListNodePtr head);
int max(ListNodePtr head);
int max2(ListNodePtr head);
ListNodePtr appendTo( ListNodePtr head, Data v);
ListNodePtr last(ListNodePtr head);
void printE(ListNode * e);
ListNodePtr onlyEven(ListNodePtr head);
ListNodePtr reverseList(ListNodePtr head);
ListNodePtr appendListTo(ListNodePtr head,ListNodePtr altraLista);


int main(int argc, const char * argv[]) {
    int arr[MAX_ELEMS] = {10, 20, 300, 40, 50};


    ListNodePtr head = NULL;
    
    head = buildFromArray( head, arr, MAX_ELEMS);

    print(head, false);
    printf("\nreverse: \n");
    print(head, true);
    printf("\n");
    
    int s = somma(head);
    printf("%d\n", s);
    
    int maxx = max(head);
    printf("%d\n", maxx);
    
    int maxx2 = max2(head);
    printf("%d\n", maxx2);
    
    ListNodePtr lastE = last(head);
    printE(lastE);
    printf("\n");
    
    head = appendTo(head, 111);
    print(head, false);
    printf("\n");

    ListNodePtr evens = onlyEven(head);
    print(evens, false);
    printf("\n");
    
    // prima con head vuota:
    int arr2[] = {333,444,555};
    ListNodePtr appended =
    appendListTo(NULL, //head,
                 buildFromArray(NULL, arr2, 3));
    print(appended, false);

    printf("\n");
    int arr3[] = {666,777,888};
    ListNodePtr appended3 =
    appendListTo(head,
                 buildFromArray(NULL, arr3, 3));
    print(appended3, false);

    printf("\n");

    printf("reverse:\n");
    int arr_r[] = {100,200,300};
    ListNodePtr toBeReversed = buildFromArray( head, arr_r, 3);
    ListNodePtr reversed = reverseList(toBeReversed);
    
    print(reversed, false);

    printf("\n");

    return 0;
}

// functions:
bool isEmpty(ListNodePtr head){
    if (head == NULL){
        return  true;
    }
    return false;
}

bool isLast(ListNodePtr head){
    if (head == NULL){
        return  false;
    }
    if (head->nextPtr == NULL)
        return true;

    return false;
}

void fillInitial(ListNode * e, Data value){
    e->data = value;
    e->nextPtr = NULL;
}

void printE(ListNode * e){
    if (e == NULL){
        printf("");
        return;
    }
    
    printf("| %d | ->", e->data);
}

// Ricorsiva
ListNodePtr last(ListNodePtr head){
    if (head == NULL){
        return  NULL;
    }
    if (head->nextPtr == NULL)
        return head; // we found, only one elem OR we are at the end of a list.
    return last(head->nextPtr);
}


ListNodePtr tail(ListNodePtr head){
    if (head == NULL){
        return  NULL;
    }
    
    return head->nextPtr;
}


// have to work even if head is null
ListNodePtr appendTo( ListNodePtr head, Data v){

    ListNodePtr justAllocated = (ListNode*) malloc(sizeof(ListNode));
    fillInitial(justAllocated, v);

    if (head == NULL){
        return justAllocated;
    }
    
    ListNodePtr lastE = last(head);
    lastE->nextPtr = justAllocated;
    return head;
}


// Ricorsiva
ListNodePtr buildFromArray(ListNodePtr head, int arr[], int n_elems){
    if (n_elems<=0){
        return NULL;
    }
    
    // in ANY case allocate:
    ListNode * justAllocated = (ListNode*) malloc(sizeof(ListNode));
    
    Data v = *arr;
    fillInitial(justAllocated, v);

    /*
    // Caso di lista inizialmente vuota E PASSO RICORSIVO
    if (head == NULL) {
        justAllocated->next = buildFromArray(NULL, arr+1,  n_elems-1);
        return justAllocated;
    }
    return head; // we anyway return head
     */
    
    // joining both:
    justAllocated->nextPtr = buildFromArray(NULL, arr+1,  n_elems-1);
    return justAllocated;
    
}


void print(ListNodePtr head, bool reverse){
    if (head == NULL){
        printE(NULL);
        return;
    }
    
    if (!reverse){
        printE(head);
        print(head->nextPtr, false);
        return;
    }
    
    // reverse:
    print(head->nextPtr, true);
    printE(head);
    
}

int somma(ListNodePtr head){
    if (head == NULL)
        return  0;
    
    return head->data + somma(head->nextPtr);
}

// vale solo se interi positivi...
int max(ListNodePtr head){
    if (head == NULL)
        return  0;
    
    int first = head->data;
    int max_of_tail = max(tail(head));

    if (first>max_of_tail)
        return first;
                          
    return max_of_tail;
}


// super compatto ma iniefficiente
int max2(ListNodePtr head){
    if (head == NULL)
        return  0;
    
    int first = head->data;
    if (first>max2(tail(head)))
        return first;
    
    return max2(tail(head));
}


ListNodePtr onlyEven(ListNodePtr head){
    if (head == NULL)
        return  NULL;
    
    Data v = head->data;
    
    if (v%2 == 0){
        // allocate and join the tail of evens:
        ListNodePtr newList = appendTo(NULL, v); // append does work on NULL...
        newList->nextPtr = onlyEven(tail(head));
        return  newList;
    }
    
    // first is NOT even:
    // simply return even on TAIL:
    return onlyEven(tail(head));
}

//ATTENZIONE! non vogliamo concatenare le liste!
ListNodePtr appendListTo(
                         ListNodePtr head,
                         ListNodePtr altraLista){
    
    if (altraLista == NULL)
        return head;
    
    if (head == NULL){
        int first = altraLista->data;

        ListNodePtr newList = appendTo(NULL, first);
        newList->nextPtr = appendListTo(newList, altraLista->nextPtr);
    }
    
    // head non è vuota:
    Data first = altraLista->data;
    head = appendTo(head, first);
    head = appendListTo(head,  tail(altraLista));

//    ListaDiElem ultimo = last(head);
//    ultimo->next = altraLista;
    return head;
}

ListNodePtr reverseList(ListNodePtr head){
    if (head == NULL)
    return NULL;
    
    if (isLast(head))
        return head;
    
    // "appendi il PRIMO elemento alla reverse della coda":
    Data primoValore = head->data;
    
    ListNodePtr l = appendTo(reverseList(tail(head)), primoValore);
    return l;
    
}
